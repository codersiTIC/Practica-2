.. automodule:: receptari
   :synopsis: Un receptari conté receptes, amb múltiples mètodes per manipular-les.
   :members:
