.. automodule:: recepta
   :synopsis: Una classe per poder manipular receptes, conté productes i quantitats
   :members:
