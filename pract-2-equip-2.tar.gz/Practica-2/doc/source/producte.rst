.. automodule:: producte
   :synopsis: Simplement un producte és un objecte amb un nom com a atribut.
   :members:
