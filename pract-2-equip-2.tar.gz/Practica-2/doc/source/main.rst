.. automodule:: main
   :synopsis: El programa que encapsula tots els mòduls.
   :members:
