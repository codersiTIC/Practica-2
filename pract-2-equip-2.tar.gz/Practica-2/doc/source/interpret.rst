.. automodule:: interpret
   :synopsis: És un intèrpret d'ordres, on hi tindrem un propi prompt per a l'usuari.
   :members:
